const printNames = function(names) {
    names.forEach(el => console.log(el));   
}; 
 
function titleize (names, printCallback) {
    let full_name_arr = names.map(function(name) {
        return `Mx. ${name} Jingleheimer Schmidt` 
    });
    return printCallback(full_name_arr);
}; 

// titleize(["Mary", "Brian", "Leo"], printNames);

// > titleize(["Mary", "Brian", "Leo"], printCallback);
// Mx. Mary Jingleheimer Schmidt
// Mx. Brian Jingleheimer Schmidt
// Mx. Leo Jingleheimer Schmidt

function Elephant(name, height, tricks) {
    this.name = name;
    this.height = height;
    this.tricks = tricks;
}
e1 = new Elephant("Earl", 2, ["pooping a plate"]);
e2 = new Elephant("Houdini", 2,["eating a cake"]);

Elephant.prototype.trumpet = function(){
    console.log(`${this.name} he elephant goes 'phrRRRRRRRRRRR!!!!!!!`)
};

Elephant.prototype.grow = function() {
    this.height += 12
};

// Elephant.prototype.addTrick = Function(trick) {

// }

console.log(e2.grow)
console.log(e2)